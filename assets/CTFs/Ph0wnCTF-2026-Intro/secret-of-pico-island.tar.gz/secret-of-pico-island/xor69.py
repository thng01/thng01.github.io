input_file = "./tools/scummtr-0.5.1-linux86/DUMP/DISK_0001/LE/LF_0058/SC_0098"
output_file = "9869"

with open(input_file, "rb") as f:
    data = f.read()

xored = bytes([b ^ 0x69 for b in data])

with open(output_file, "wb") as f:
    f.write(xored)
